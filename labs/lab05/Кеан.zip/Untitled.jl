1032205169%70+1

using Plots
using DifferentialEquations

x0 = 3
y0 = 8
u0 = [x0; y0]

t0 = 0
tmax = 100
tspan = (t0, tmax)
t = collect(LinRange(0, 100, 1000))

a = 0.22
b = 0.051
c = 0.33
d = 0.041

function syst(dy, y, p, t)
    dy[1] = -a*y[1] + b*y[1]*y[2]
    dy[2] = c*y[2] - d*y[1]*y[2]
end

prob = ODEProblem(syst, u0, tspan)

sol = solve(prob, saveat = t)

plot(sol)

savefig("03.png")

plot(sol, idxs=(1, 2))

savefig("04.png")


